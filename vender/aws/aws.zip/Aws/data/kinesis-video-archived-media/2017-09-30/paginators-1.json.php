<?php
// This file was auto-generated from sdk-root/src/data/kinesis-video-archived-media/2017-09-30/paginators-1.json
return [ 'pagination' => [ 'ListFragments' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'result_key' => 'Fragments', ], ],];
